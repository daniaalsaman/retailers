import { useFormik } from "formik";

const ProductForm = ({ initialValues, onSubmit }: any) => {
  const formik = useFormik({
    initialValues,
    onSubmit,
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      {formik.values.title && (
        <>
          <input
            type="text"
            name="title"
            value={formik.values.title}
            onChange={formik.handleChange}
          />
          <input
            type="text"
            name="category"
            value={formik.values.category}
            onChange={formik.handleChange}
          />
        </>
      )}
      {formik.values.description && (
        <input
          type="text"
          name="description"
          value={formik.values.description}
          onChange={formik.handleChange}
        />
      )}
      {formik.values.description && (
        <input
          type="text"
          name="price"
          value={formik.values.price}
          onChange={formik.handleChange}
        />
      )}
      <button type="submit">Submit</button>
    </form>
  );
};
export default ProductForm;
