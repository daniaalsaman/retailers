import React from "react";

const priceBodyTemplate = (rowData: any) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(rowData.price);
};

export default priceBodyTemplate;
