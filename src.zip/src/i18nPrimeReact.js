import { addLocale, locale } from "primereact/api";
import i18n from "./i18n"; // import your i18next setup
import { useTranslation } from "react-i18next";

export const setupPrimeReactLocales = () => {
  const { t } = useTranslation();

  addLocale("en", {
    startsWith: t("filter.startsWith"),
    contains: t("filter.contains"),
    notContains: t("filter.notContains"),
    endsWith: t("filter.endsWith"),
    equals: t("filter.equals"),
    notEquals: t("filter.notEquals"),
    noFilter: t("filter.noFilter") || "No Filter",
    lt: t("filter.lt"),
    lte: t("filter.lte"),
    gt: t("filter.gt"),
    gte: t("filter.gte"),
    dateIs: t("filter.dateIs"),
    dateIsNot: t("filter.dateIsNot"),
    dateBefore: t("filter.dateBefore"),
    dateAfter: t("filter.dateAfter"),
    clear: t("filter.clear") || "Clear",
    apply: t("filter.apply") || "Apply",
    matchAll: t("filter.matchAll") || "Match All",
    matchAny: t("filter.matchAny") || "Match Any",
    addRule: t("filter.addRule") || "Add Rule",
    removeRule: t("filter.removeRule") || "Remove Rule",
    accept: t("filter.accept") || "Yes",
    reject: t("filter.reject") || "No",
    choose: t("filter.choose") || "Choose",
    upload: t("filter.upload") || "Upload",
    cancel: t("filter.cancel") || "Cancel",
  });

  addLocale("ar", {
    startsWith: t("filter.startsWith"),
    contains: t("filter.contains"),
    notContains: t("filter.notContains"),
    endsWith: t("filter.endsWith"),
    equals: t("filter.equals"),
    notEquals: t("filter.notEquals"),
    noFilter: t("filter.noFilter") || "بدون فلتر",
    lt: t("filter.lt"),
    lte: t("filter.lte"),
    gt: t("filter.gt"),
    gte: t("filter.gte"),
    dateIs: t("filter.dateIs"),
    dateIsNot: t("filter.dateIsNot"),
    dateBefore: t("filter.dateBefore"),
    dateAfter: t("filter.dateAfter"),
    clear: t("filter.clear") || "مسح",
    apply: t("filter.apply") || "تطبيق",
    matchAll: t("filter.matchAll") || "مطابقة الكل",
    matchAny: t("filter.matchAny") || "مطابقة أي",
    addRule: t("filter.addRule") || "إضافة قاعدة",
    removeRule: t("filter.removeRule") || "إزالة قاعدة",
    accept: t("filter.accept") || "نعم",
    reject: t("filter.reject") || "لا",
    choose: t("filter.choose") || "اختر",
    upload: t("filter.upload") || "رفع",
    cancel: t("filter.cancel") || "إلغاء",
  });

  locale(i18n.language); // Set the initial locale
};
